import discord
import os
import random
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client( intents=intents) #command_prefix='!',
facts = ['Парниковый эффект был обнаружен Жозефом Фурье в 1824 году и впервые был количественно исследован Сванте Аррениусом в 1896.', 'Ученые проанализировали изменение уровня морей, приливы, волны и штормовые нагоны вплоть до 2100 года и составили неутешительную картину: к концу века уровень воды в Европе будет выше нынешнего на 51-87 сантиметров. Следствием станет тот факт, что катастрофические "наводнения столетия" будут повторяться ежегодно.', 'Из европейских городов уйти под воду в ближайшие десятилетия рискуют Амстердам и Венеция, в США — Новый Орлеан, на Ближнем Востоке — иракский порт Басра, в Юго-Восточной Азии — Калькутта в Индии, Хошимин во Вьетнаме, Тяньцзинь и Шанхай в Китае', 'В первую очередь после поднятия уровня воды пострадают регионы Китая, Индии, Индонезии и Вьетнама, где огромная часть населения занимает земли ниже прогнозируемой линии прилива. По предварительным прогнозам это затронет до 15% нынешнего населения мира, а это около одного миллиарда человек.']
@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    #1 приветствие
    if message.content.startswith('hello'):
        with open(f'images/гп1.jpg', 'rb') as f:
            picture = discord.File(f)
            await message.channel.send(file=picture) 
        await message.channel.send("Привет. Знаешь ли ты о проблемах, которые окружают твой мир? Я создан для осведомления пользователей об одной огромной проблеме - глобальное потепление. Список команд можно проверить тут - !commands")
    
    #2 основн
    if message.content.startswith('global_warming'):
        await message.channel.send('Глобальное потепление — распространенное название изменения климата, которое идет уже около двух веков. С 1800-х годов по большой части фактором вызова глобального потепление является человеческая деятельность. Например сжигание ископаемых видов топлива, в результате образуются газы, удерживающие тепло в атмосфере.')
   
    #3 решение
    if message.content.startswith('solution'):
        with open(f'images/гп4.png', 'rb') as f:
            picture = discord.File(f)
            await message.channel.send(file=picture)
        await message.channel.send("В качестве решений я предлагаю вам такие варианты: 1) отказаться от личной машины, больше пользоваться общественным транспортом или же велосипедом. 2) Экономьте энергию. Отключайте электроприборы, которыми не пользуетесь. Как можно больше заменяйте электроприборы, например вместо электронной сушилки можно высушить на обычной или на балконе. 3) Утилизация отходов приводит к сокращению энергопотребления, но еще лучше было бы повторно использовать продукцию или сокращать масштабы потребления. 4) Как можно больше освещайте эту проблему с окружением, рекламируйте меня и подобные проекты. Призывайте общество к действиям указанным выше.")
    
    #4 океан
    if message.content.startswith('ocean'):
        await message.channel.send("Океан является крупнейшим поглотителем углерода на планете. Его загрязнение пластиком влияет на глобальное потепление. Пластик по мере разложения высвобождает метан, что вносит существенный вклад в глобальное потепление")
    
    #5 температура
    if message.content.startswith('temperature'):
        with open(f'images/гп5.jpg', 'rb') as f:
            picture = discord.File(f)
            await message.channel.send(file=picture)
        await message.channel.send("Средняя глобальная температура Земли около 15 градусов Цельсия. Это невероятно плохие результаты.")
    
    #6 животные
    if message.content.startswith('animals'):
        with open(f'images/гп2.jpg', 'rb') as f:
            picture = discord.File(f)
            await message.channel.send(file=picture)
        await message.channel.send("Глобальное потепление приводит к тому, что миграция животных начинается раньше, чем обычно, поэтому детеныши не успевают окрепнуть и гибнут, пытаясь преодолеть препятствия, например, реки. Отставшие от стада животные становятся жертвами браконьеров и бродячих собак")
    
    #7 ледник
    if message.content.startswith('gracier'):
        with open(f'images/гп3.jpg', 'rb') as f:
            picture = discord.File(f)
        await message.channel.send(file=picture)
        await message.channel.send("Таяние ледников приведет к дисбалансу мирового климата, в результате планета все чаще будет сталкиваться с сильными дождями, штормами, ураганами и засухой. На Земле существование многих видов животных и растений напрямую зависит от ледников.")
    
    #8 контакт
    if message.content.startswith('contact'):
        await message.channel.send("tg:@vladifox")
    
    #9 добавление фактов
    #if message.content.startswith('!add'):
       #addfacts = await message.channel.send(input("Вы можете добавить свои факты о глобальном потеплении, которые я буду выдавать через команду !random"))
    #facts.append(addfacts)
    
    #10 рандом
    if message.content.startswith('random'):
        await message.channel.send(random.choice(facts))
    
    #11 команды
    if message.content.startswith('commands'):
        await message.channel.send("!global_warming - общая информация о глобальном потеплении, !solution - решения, которые помогут предотвратить глобальное потепление, !ocean - влияние океана на глобальное потепление, !animals - влияние глобального потепления на животных, !gracier - влияние таяния ледников на мир, !add - добавить факт в базу данных бота, !random - рандомный факт о глобальном потеплении, !temperature - средняя температура в мире")
                                  
    elif message.content.startswith('$bye'):
        await message.channel.send("\\U0001f642")
    #else:
        #await message.channel.send(message.content)
        
client.run("MTI3MTgxODg2MzU5OTk0MzY4MQ.GlamBx.rMuy79iQMIqfRpwoDaFRHg4GQ-xuOPH-XUSxxc")